// Form Validation and Submission
document.addEventListener("DOMContentLoaded", () => {
  const emailForm = document.getElementById("emailForm")

  if (emailForm) {
    emailForm.addEventListener("submit", (e) => {
      e.preventDefault()

      if (!emailForm.checkValidity()) {
        emailForm.classList.add("was-validated")
        return
      }

      const formData = {
        firstName: document.getElementById("firstName").value,
        email: document.getElementById("email").value,
        consent: document.getElementById("consent").checked,
      }

      console.log("[v0] Form submitted with data:", formData)

      // Send to email service (Mailchimp, Fluent Forms, etc.)
      submitToEmailService(formData)
    })
  }

  // Download button functionality
  const downloadBtn = document.getElementById("downloadBtn")
  if (downloadBtn) {
    downloadBtn.addEventListener("click", (e) => {
      e.preventDefault()
      // Replace with actual PDF URL
      window.location.href = "/downloads/PhD-Student-Planner.pdf"
    })
  }

  // Smooth scroll for navigation links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const target = this.getAttribute("href")
      if (target !== "#" && document.querySelector(target)) {
        e.preventDefault()
        document.querySelector(target).scrollIntoView({
          behavior: "smooth",
        })
      }
    })
  })

  // AOS-like animation on scroll (simple version)
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("fade-in")
      }
    })
  }, observerOptions)

  document.querySelectorAll(".feature-card, .preview-card, .step-card").forEach((el) => {
    observer.observe(el)
  })
})

// Submit to Email Service
function submitToEmailService(formData) {
  // IMPORTANT: Replace these URLs with your actual service endpoints

  // Option 1: Mailchimp API
  // const mailchimpEndpoint = 'YOUR_MAILCHIMP_LIST_URL';

  // Option 2: Fluent Forms Webhook
  // const fluentFormsEndpoint = 'YOUR_FLUENT_FORMS_WEBHOOK_URL';

  // Option 3: Custom WordPress API
  const wpApiEndpoint = "/wp-json/phd-planner/v1/subscribe"

  fetch(wpApiEndpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(formData),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok")
      }
      return response.json()
    })
    .then((data) => {
      console.log("[v0] Submission successful:", data)
      handleSubmissionSuccess()
    })
    .catch((error) => {
      console.error("[v0] Error:", error)
      handleSubmissionError()
    })
}

// Handle successful submission
function handleSubmissionSuccess() {
  const emailModal = document.getElementById("emailModal")
  const emailForm = document.getElementById("emailForm")
  const modalBody = emailModal.querySelector(".modal-body")

  // Clear form
  emailForm.classList.remove("was-validated")
  emailForm.reset()

  // Show success message
  modalBody.innerHTML = `
        <div class="text-center py-4">
            <div style="font-size: 3rem; margin-bottom: 1rem;">
                <i class="fas fa-check-circle text-success"></i>
            </div>
            <h3 class="fw-bold text-dark mb-2">Check Your Email!</h3>
            <p class="text-muted mb-3">
                Your PhD Student Planner is on its way. Check your inbox (and spam folder just in case) for your download link.
            </p>
            <p class="small text-success">
                <i class="fas fa-check"></i> You'll receive updates with planning tips and resources
            </p>
            <button type="button" class="btn btn-primary mt-3" data-bs-dismiss="modal">
                Close
            </button>
        </div>
    `
}

// Handle submission error
function handleSubmissionError() {
  const emailForm = document.getElementById("emailForm")
  const alert = document.createElement("div")
  alert.className = "alert alert-danger alert-dismissible fade show"
  alert.innerHTML = `
        <strong>Error!</strong> Something went wrong. Please try again or contact support.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `
  emailForm.parentElement.insertBefore(alert, emailForm)
}

// Scroll to top functionality
window.addEventListener("scroll", () => {
  const scrollBtn = document.getElementById("scrollToTop")
  if (scrollBtn) {
    if (window.pageYOffset > 300) {
      scrollBtn.style.display = "block"
    } else {
      scrollBtn.style.display = "none"
    }
  }
})

// Social sharing
document.querySelectorAll(".social-share").forEach((btn) => {
  btn.addEventListener("click", function (e) {
    const network = this.dataset.network
    const url = window.location.href
    const title = document.title

    let shareUrl = ""

    switch (network) {
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`
        break
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`
        break
      case "linkedin":
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`
        break
      case "email":
        shareUrl = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(url)}`
        break
    }

    if (shareUrl) {
      window.open(shareUrl, "_blank")
    }
  })
})
